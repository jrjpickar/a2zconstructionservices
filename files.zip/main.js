// ============================================
// A2Z Construction Services — main.js
// ============================================

document.addEventListener('DOMContentLoaded', function () {

  // --- Year ---
  const yr = document.getElementById('yr');
  if (yr) yr.textContent = new Date().getFullYear();

  // --- Hamburger ---
  const ham = document.getElementById('hamburger');
  const navLinks = document.getElementById('navLinks');
  if (ham && navLinks) {
    ham.addEventListener('click', function () {
      this.classList.toggle('open');
      navLinks.classList.toggle('open');
    });
    // close on link click
    navLinks.querySelectorAll('a').forEach(function (a) {
      a.addEventListener('click', function () {
        ham.classList.remove('open');
        navLinks.classList.remove('open');
      });
    });
  }

  // --- Sticky nav shadow ---
  const navbar = document.getElementById('navbar');
  if (navbar) {
    window.addEventListener('scroll', function () {
      navbar.style.boxShadow = window.scrollY > 10 ? '0 2px 16px rgba(0,0,0,.08)' : 'none';
    });
  }

  // --- Services slider (desktop carousel) ---
  const track = document.getElementById('servicesTrack');
  const prevBtn = document.getElementById('svcPrev');
  const nextBtn = document.getElementById('svcNext');
  if (track && prevBtn && nextBtn) {
    let idx = 0;
    function getVisible() {
      const w = window.innerWidth;
      if (w < 600) return 1;
      if (w < 900) return 2;
      return 4;
    }
    function updateSlider() {
      const cards = track.querySelectorAll('.svc-card');
      const visible = getVisible();
      const max = Math.max(0, cards.length - visible);
      idx = Math.min(idx, max);
      const pct = (100 / visible) * idx;
      track.style.transform = 'translateX(-' + pct + '%)';
      prevBtn.style.opacity = idx === 0 ? '0.4' : '1';
      nextBtn.style.opacity = idx >= max ? '0.4' : '1';
    }
    prevBtn.addEventListener('click', function () { idx = Math.max(0, idx - 1); updateSlider(); });
    nextBtn.addEventListener('click', function () {
      const cards = track.querySelectorAll('.svc-card');
      const visible = getVisible();
      const max = Math.max(0, cards.length - visible);
      idx = Math.min(max, idx + 1);
      updateSlider();
    });
    window.addEventListener('resize', updateSlider);
    updateSlider();
  }

  // --- Modal helpers ---
  window.openModal = function (type) {
    const el = document.getElementById(type + 'Modal');
    if (el) { el.classList.add('open'); document.body.style.overflow = 'hidden'; }
  };
  window.closeModal = function (type) {
    const el = document.getElementById(type + 'Modal');
    if (el) { el.classList.remove('open'); document.body.style.overflow = ''; }
  };
  document.querySelectorAll('.modal-overlay').forEach(function (el) {
    el.addEventListener('click', function (e) {
      if (e.target === this) {
        this.classList.remove('open');
        document.body.style.overflow = '';
      }
    });
  });
  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape') {
      document.querySelectorAll('.modal-overlay.open').forEach(function (el) {
        el.classList.remove('open');
      });
      document.body.style.overflow = '';
    }
  });

  // --- Contact form (Netlify-compatible) ---
  const form = document.getElementById('contactForm');
  const successEl = document.getElementById('formSuccess');
  if (form && successEl) {
    form.addEventListener('submit', function (e) {
      // Let Netlify handle the real POST — only intercept for preview/local
      const isNetlify = window.location.hostname.includes('netlify') || window.location.hostname.includes('a2z');
      if (!isNetlify) {
        e.preventDefault();
        form.style.display = 'none';
        successEl.style.display = 'block';
      }
      // On real Netlify, form posts naturally — Netlify intercepts it
    });
  }

  // --- Smooth scroll for anchor links ---
  document.querySelectorAll('a[href^="#"]').forEach(function (a) {
    a.addEventListener('click', function (e) {
      const target = document.querySelector(this.getAttribute('href'));
      if (target) {
        e.preventDefault();
        const offset = 80;
        const top = target.getBoundingClientRect().top + window.scrollY - offset;
        window.scrollTo({ top: top, behavior: 'smooth' });
      }
    });
  });

  // --- Fade-in on scroll ---
  const fadeEls = document.querySelectorAll('.svc-card, .testi-card, .value-card, .stat-item, .article-row');
  if ('IntersectionObserver' in window && fadeEls.length) {
    fadeEls.forEach(function (el) { el.style.opacity = '0'; el.style.transform = 'translateY(18px)'; el.style.transition = 'opacity .45s ease, transform .45s ease'; });
    const obs = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          entry.target.style.opacity = '1';
          entry.target.style.transform = 'translateY(0)';
          obs.unobserve(entry.target);
        }
      });
    }, { threshold: 0.12 });
    fadeEls.forEach(function (el) { obs.observe(el); });
  }

});
